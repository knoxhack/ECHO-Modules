package com.echoplatform.echocore.api;

public final class EchoOptionalServices {
    private EchoOptionalServices() {
    }

    public static IRuntimeBudgetService runtimeGuardOrNoOp() {
        return EchoCoreServices.runtimeBudgetService();
    }

    public static ISoundService soundCoreOrNoOp() {
        return EchoCoreServices.soundService();
    }

    public static IThemeService themeCoreOrNoOp() {
        return EchoCoreServices.themeService();
    }
}
